/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rummikub_java_project;

/**
 *
 * @author romma
 */
public class ColorDetails {
    private int colorID;
    private String colorName;

    public ColorDetails(int colorID, String colorName) {
        this.colorID = colorID;
        this.colorName = colorName;
    }

    public int getColorID() {
        return colorID;
    }

    public String getColorName() {
        return colorName;
    }
    
    
    
    
}
